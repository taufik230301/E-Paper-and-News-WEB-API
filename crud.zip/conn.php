<?php
// localhost = localhost
// username = pppkpusr_taufik
// password = ag7debctaxld
// dbname = pppkpusr_classic_news
$conn=new mysqli("localhost","pppkpusr_taufik","ag7debctaxld","pppkpusr_classic_news");

if($conn){

	//echo "Connection Stablished";
}
else
{
	//echo "falied";
}

?>
